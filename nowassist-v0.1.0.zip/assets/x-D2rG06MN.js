import{c as o}from"./styles-B9ZRb-5T.js";const c=[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]],n=o("chevron-up",c);const e=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],d=o("x",e);export{n as C,d as X};
//# sourceMappingURL=x-D2rG06MN.js.map

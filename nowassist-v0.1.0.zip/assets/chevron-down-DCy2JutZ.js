import{c as o}from"./styles-C_eKyovT.js";const n=[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]],e=o("chevron-down",n);export{e as C};
//# sourceMappingURL=chevron-down-DCy2JutZ.js.map
